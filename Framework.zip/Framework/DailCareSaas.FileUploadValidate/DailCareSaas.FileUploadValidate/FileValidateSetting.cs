﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailCareSaas.FileUploadValidate
{
    public class FileValidateSetting
    {
        public int MaxFileSize { get; set; } =0;
        public int MinFileSize { get; set; } = 0;
        public string FileTypes { get; set; } = null!;
        public List<FileSignature> FileSignatures { get; set; }
    }
    public class FileSignature
    {
        public string Extension { get; set; }
        public string Signature { get; set; }
        public int[] GetArrayFromSignature()
        {

            string[] split = Signature.Split(' ');
            int[] signatureArray = new int[split.Length];
            int index = 0;
            foreach (String hex in split)
            {
                signatureArray[index++] = Convert.ToInt32(hex, 16);
            }
            return signatureArray;
        }
    }
}
