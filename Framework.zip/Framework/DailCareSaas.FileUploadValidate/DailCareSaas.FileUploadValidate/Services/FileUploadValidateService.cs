﻿using DailCareSaas.FileUploadValidate.Validation;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Size = DailCareSaas.FileUploadValidate.Validation.Size;

namespace DailCareSaas.FileUploadValidate.Services
{
    public class FileUploadValidateService : IFileUploadValidateService
    {
        private readonly IConfiguration _configuration;
        private List<string> fileTypes = null;
        private FileValidateSetting fileValidateSetting;
        private readonly FileExtension objExtension;
        private readonly Size objSize;
        private readonly Signature objSignature;
        public FileUploadValidateService(IConfiguration configuration)
        {
            _configuration = configuration;
            fileValidateSetting =  _configuration.GetSection("FileValidateSetting").Get<FileValidateSetting>();
            objExtension = new FileExtension(configuration);
            objSize = new Size(configuration);
            objSignature = new Signature(configuration);
        }
        public Response<bool> ValidateFile(IFormFile file,string type)
        {
            fileValidateSetting = type == "Document" ? _configuration.GetSection("DocumentFileValidateSetting").Get<FileValidateSetting>() : _configuration.GetSection("FileValidateSetting").Get<FileValidateSetting>();
            Response<bool> response = new Response<bool>();
            response.Errors ??= new Dictionary<string, string[]>();
            response.Result = true;          
            if (file == null)
            {
                response.Errors.Add("FileEmpty", new string[] { "File is empty" });
                response.Result = false;
                return response;
            }
            if (fileValidateSetting == null)
            {
                response.Errors.Add("FileValidateSetting", new string[] { "Please add FileValidateSetting in appsettings.json e.g \"FileValidateSetting\": {\"MaxFileSize\": 8888, \"MinFileSize\": 1, \"FileTypes\": \"jpg,jpeg,png\", \"FileSignatures\": [ { \"Extension\": \".IMG\", \"Signature\": \"50 49 43 54 00 08\"},{ \"Extension\": \".IMG\", \"Signature\": \"EB 3C 90 2A\"},{ \"Extension\": \".IMG\",\"Signature\": \"53 43 4D 49\"}, { \"Extension\": \".JPEG\", \"Signature\": \"FF D8 FF E0\" },{ \"Extension\": \".JPEG\", \"Signature\": \"FF D8 FF E2\" }, { \"Extension\": \".JPEG\", \"Signature\": \"FF D8 FF E3\"},{ \"Extension\": \".JPG\", \"Signature\": \"FF D8 FF E0\" },{ \"Extension\": \".JPG\", \"Signature\": \"FF D8 FF E1\"},{  \"Extension\": \".JPG\", \"Signature\": \"FF D8 FF E8\" }, { \"Extension\": \".PNG\", \"Signature\": \"89 50 4E 47 0D 0A 1A 0A\" }]}" });
                response.Result = false;
                return response;
            }
            objExtension.IsValidate(ref response, file, type);
            objSize.IsValidate(ref response, file, type);
            objSignature.IsValidate(ref response, file, type);
            return response;

        }
    }
}
