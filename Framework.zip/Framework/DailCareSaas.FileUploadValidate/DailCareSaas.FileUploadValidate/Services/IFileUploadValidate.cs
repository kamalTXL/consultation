﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailCareSaas.FileUploadValidate.Services
{
    public interface IFileUploadValidateService
    {
        Response<bool> ValidateFile(IFormFile file,string type);
    }
}
