﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailCareSaas.FileUploadValidate.Utility.Enums
{
    public enum FileEntityTypeEnums
    {
        ProfilePic,
        Document
    }
}
