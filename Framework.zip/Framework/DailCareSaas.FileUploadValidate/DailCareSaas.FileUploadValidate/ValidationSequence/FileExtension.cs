﻿using DailCareSaas.FileUploadValidate.Utility.Enums;
using DailCareSaas.FileUploadValidate.ValidationSequence;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailCareSaas.FileUploadValidate.Validation
{
    internal class FileExtension : Sequence
    {
        private readonly IConfiguration _configuration;
        private  FileValidateSetting fileValidateSetting;
        private List<string> fileTypes = null;
        public FileExtension(IConfiguration configuration)
        {
            _configuration = configuration;
            fileValidateSetting = _configuration.GetSection("FileValidateSetting").Get<FileValidateSetting>();

        }
        public override Response<bool> IsValidate(ref Response<bool> response, IFormFile file, string type)
        {
            fileValidateSetting = type == Convert.ToString(FileEntityTypeEnums.Document) ? _configuration.GetSection("DocumentFileValidateSetting").Get<FileValidateSetting>() : _configuration.GetSection("FileValidateSetting").Get<FileValidateSetting>();
            fileTypes = fileValidateSetting != null && fileValidateSetting.FileTypes != null ? fileValidateSetting.FileTypes.Split(',').Select(x => x.ToLower().Trim()).ToList() : new List<string>();
            if (fileTypes!=null && fileTypes.Count==0)
            {
                response.Result = false;
                response.AddError("FileType", "FileType should not be empty");
                return response;
            }
            if (!fileTypes.Contains("*") && !fileTypes.Contains(Path.GetExtension(file.FileName).Substring(1).ToLower().Trim()))
            {
                response.Result = false;
                response.Errors.Add("FileTypes", new string[] { $"File type ({Path.GetExtension(file.FileName).Substring(1)}) does not allowed. File type should be {string.Join(",", fileTypes)}" });
            }
            return response;
        }
    }
}
