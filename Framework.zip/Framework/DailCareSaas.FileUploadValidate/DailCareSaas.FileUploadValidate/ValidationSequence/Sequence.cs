﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailCareSaas.FileUploadValidate.ValidationSequence
{
    internal abstract class Sequence
    {
        public abstract Response<Boolean> IsValidate(ref Response<bool> response, IFormFile file, string type);
    }
}
