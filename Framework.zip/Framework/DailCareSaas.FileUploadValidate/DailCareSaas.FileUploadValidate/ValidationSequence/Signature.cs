﻿using DailCareSaas.FileUploadValidate.Utility.Enums;
using DailCareSaas.FileUploadValidate.ValidationSequence;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailCareSaas.FileUploadValidate.Validation
{
    internal class Signature : Sequence
    {
        private readonly IConfiguration _configuration;
        private  FileValidateSetting fileValidateSetting;
        private List<FileSignature> fileSignatures;
        private readonly Dictionary<string, List<int[]>> signatures = new Dictionary<string, List<int[]>>();
        public Signature(IConfiguration configuration)
        {
            _configuration = configuration;
            fileValidateSetting = _configuration.GetSection("FileValidateSetting").Get<FileValidateSetting>();
            
        }
        public override Response<bool> IsValidate( ref Response<bool> response, IFormFile file, string type)
        {
            fileValidateSetting = type == Convert.ToString(FileEntityTypeEnums.Document) ? _configuration.GetSection("DocumentFileValidateSetting").Get<FileValidateSetting>() : _configuration.GetSection("FileValidateSetting").Get<FileValidateSetting>();
            SetFileType();
            var extension = Path.GetExtension(file.FileName).ToLower();
            if (fileValidateSetting!.FileSignatures!=null && !IsExtensionValid(file))
            {
                response.Result = false;
                response.Errors.Add("FileSignature", new string[] { $" {extension} has invalid signature." });
            }
            return response;
        }
        private bool IsExtensionValid(IFormFile file)
        {
            var extension = Path.GetExtension(file.FileName).ToLower();
            if (!signatures.ContainsKey(extension))
            {
                return false;
            }
            var acceptedSignatures = signatures[extension];
            using (var ms = new MemoryStream()) {
                file.CopyTo(ms);
                var fileBytes = ms.ToArray();
                foreach (var acceptedSignature in acceptedSignatures)
                {

                    for (int i = 0; i < acceptedSignature.Length; i++)
                    {
                        if (fileBytes[i] != acceptedSignature[i])
                        {
                            break;
                        }
                        if (i == acceptedSignature.Length - 1)
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }
        private void SetFileType()
        {
            fileSignatures = fileValidateSetting != null ? fileValidateSetting.FileSignatures??new List<FileSignature>() : new List<FileSignature>();
            foreach (var fe in fileSignatures)
            {
                var ext = fe.Extension.ToLower();
                if (!signatures.ContainsKey(ext))
                {
                    signatures[ext] = new List<int[]>();
                }
                signatures[ext].Add(fe.GetArrayFromSignature());
            }
        }
    }
}
