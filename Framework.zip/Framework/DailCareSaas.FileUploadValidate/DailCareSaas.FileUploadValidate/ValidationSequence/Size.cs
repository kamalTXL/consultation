﻿using DailCareSaas.FileUploadValidate.Utility.Enums;
using DailCareSaas.FileUploadValidate.ValidationSequence;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DailCareSaas.FileUploadValidate.Validation
{
    internal class Size : Sequence
    {
        private readonly IConfiguration _configuration;
        private FileValidateSetting fileValidateSetting;
        public Size(IConfiguration configuration)
        {
            _configuration = configuration;
            fileValidateSetting = _configuration.GetSection("FileValidateSetting").Get<FileValidateSetting>();
        }
        public override Response<bool> IsValidate(ref Response<bool> response, IFormFile file, string type)
        {
            fileValidateSetting = type == Convert.ToString(FileEntityTypeEnums.Document) ? _configuration.GetSection("DocumentFileValidateSetting").Get<FileValidateSetting>() : _configuration.GetSection("FileValidateSetting").Get<FileValidateSetting>();
            long minFileSize = (fileValidateSetting.MinFileSize / 1000);
            long maxFileSize = (fileValidateSetting.MaxFileSize / 1000);
            long actualFileSize = (file.Length / 1000);
            if (fileValidateSetting.MinFileSize > fileValidateSetting.MaxFileSize)
            {
                response.Result = false;
                response.AddError("MaxFileLessThan", "Max Size of file cannot be less than min size");
            }
            else if (fileValidateSetting.MinFileSize == fileValidateSetting.MaxFileSize)
            {
                response.Result = false;
                response.AddError("MaxFileEqual", "Max Size of file cannot be equal to min size");
            }
            else if (fileValidateSetting.MinFileSize <= 0)
            {
                response.Result = false;
                response.AddError("MinFileSize", "Min Size of file cannot be less than or equal to zero");
            }
            else if (fileValidateSetting.MaxFileSize <= 0)
            {
                response.Result = false;
                response.AddError("MaxFileSize", "Max Size of file cannot be less than or equal to zero");
            }

            else if (file.Length < fileValidateSetting.MinFileSize)
            {
                response.Result = false;
                response.Errors.Add("MinSize", new string[] { $"File size ({actualFileSize} KB ) should not be less than {minFileSize} KB " });
            }
            else if (file.Length > fileValidateSetting.MaxFileSize)
            {
                response.Result = false;
                response.Errors.Add("MaxSize", new string[] { $"File size ({actualFileSize} KB) should not be greater than {maxFileSize} KB " });
            }
            return response;
        }
    }
}
