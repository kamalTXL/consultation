﻿using DialCareSaas.Api.Swagger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Api
{
    public class DialCareSaasApiCoreOptions
    {
        //commenting this code temporarily. will uncomment this code when oAuth2 is supported
        //public JwtBearerOptions JwtBearerOptions { get; set; } = new JwtBearerOptions
        //{
        //    RequireHttpsMetadata = false
        //};

        public string? SwaggerDocName { get; set; }

        public IEnumerable<string>? XmlCommentsFilePaths { get; set; }

        // default value is added to support backward compatibility
        public IEnumerable<ApiSecurity> ApiSecurities { get; set; } = new List<ApiSecurity> { ApiSecurity.ApiKey };

        public bool ApiVersioning { get; set; }
    }
}
