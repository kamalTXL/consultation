﻿using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Api
{
    public static class DIalCareSaasApiCoreExceptionExtension
    {
        public static IApplicationBuilder UseDialCareSaasApiExceptionHandler(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<DialCareSaasApiCoreExceptionMiddleware>();
        }
    }
}
