﻿namespace DialCareSaas.Api.Security
{
    public interface IProvideApiKeys
    {
        IEnumerable<ApiKey> GetApiKeys();
    }
}
