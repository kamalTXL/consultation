﻿using DialCareSaas.Api.Security;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Api
{
    public static class ServiceDependencies
    {
        public static IServiceCollection RegisterServiceDependencies(this IServiceCollection services)
        {
            services.AddSingleton<IProvideApiKeys, AppSettingsApiKeyProvider>();
            return services;
        }
    }
}
