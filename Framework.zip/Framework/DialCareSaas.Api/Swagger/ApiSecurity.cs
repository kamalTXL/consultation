﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Api.Swagger
{
    public enum ApiSecurity
    {
        ApiKey = 0,
        BearerToken = 1
    }
}
