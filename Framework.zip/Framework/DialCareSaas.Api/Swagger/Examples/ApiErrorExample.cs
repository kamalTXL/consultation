﻿using Swashbuckle.AspNetCore.Filters;

namespace DialCareSaas.Api.Swagger.Examples
{
    public class ApiErrorExample : IExamplesProvider<ApiErrorBase>
    {
        public ApiErrorBase GetExamples()
        {
            var errors = new Dictionary<string, string[]>
            {
                { "FieldName1", new string[] { "FieldName1 is required." } },
                { "FieldName2", new string[] { "The field FieldName2 must be a string with a maximum length of 20." } },
            };

            return new ApiErrorBase
            {
                Message = "Something went wrong, please try again after some time or reach out to helpdesk with Error Reference Number: b7890b612ac23d4cb90e683c03a6fdd5",
                ExceptionId = "b7890b612ac23d4cb90e683c03a6fdd5",
            };
        }
    }
}
