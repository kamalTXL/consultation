﻿using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Api.Swagger.Examples
{
    public class NotFoundErrorExample : IExamplesProvider<NotFoundErrorDetails>
    {
        public NotFoundErrorDetails GetExamples()
        {
            return new NotFoundErrorDetails()
            {
                Type = "https://tools.ietf.org/html/rfc7231#section-6.5.4",
                Title = "Not Found",
                Status = 404,
                TraceId = "00-a6cf2f052eddcc49bacfac9a725e2b0b-8252dc5114ed0044-00",
            };
        }
    }
}
