﻿namespace DialCareSaas.Core
{
#nullable disable
    public class APIResponse<T>
    {
        public APIResponse()
        {
        }

        public APIResponse(List<IDictionary<string, string>> errors)
        {
            Errors = errors;
        }

        public T Result { get; set; }

        public List<IDictionary<string, string>> Errors { get; set; }

        public void AddError(string errorCode, string errorMessage)
        {
            if (Errors==null)
            {
                Errors = new List<IDictionary<string, string>>();
            }
            var error = new Dictionary<string, string>()
            {
                {errorCode, errorMessage}
            };
            
            Errors.Add(error);
          
        }



    }
#nullable enable
}