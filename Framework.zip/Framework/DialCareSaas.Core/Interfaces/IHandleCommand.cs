﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Core
{
    public interface IHandleCommand<TCommand, TResponse>
    {
        TResponse Execute(TCommand command);
    }
}
