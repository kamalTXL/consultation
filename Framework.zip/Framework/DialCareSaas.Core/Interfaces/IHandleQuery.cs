﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Core
{
    public interface IHandleQuery<TQuery, TResponse>
    {
        TResponse Execute(TQuery query);
    }
}
