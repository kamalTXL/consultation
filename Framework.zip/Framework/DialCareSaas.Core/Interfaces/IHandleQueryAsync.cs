﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Core
{
    public interface IHandleQueryAsync<TQuery, TResponse>
    {
        Task<TResponse> ExecuteAsync(TQuery query);
    }

    public interface IHandleQueryAsync<TResponse>
    {
        Task<TResponse> ExecuteAsync();
    }
}
