﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Core.Utility
{
    public interface IUIDGenerationService
    {
        string GenerateUID(ulong root, ulong subRoot);
    }
}
