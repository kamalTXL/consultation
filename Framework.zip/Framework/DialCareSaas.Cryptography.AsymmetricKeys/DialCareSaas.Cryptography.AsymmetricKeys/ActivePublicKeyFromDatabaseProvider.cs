﻿using DialCareSaas.Core;
using DialCareSaas.Cryptography.AsymmetricKeys.Domain;

namespace DialCareSaas.Cryptography.AsymmetricKeys
{
    /// <summary>
    /// Key provider class for active public key
    /// </summary>
    public class ActivePublicKeyFromDatabaseProvider : IProvideAsymmetricPublicKey
    {
        #region PROPERTIES

        private readonly IHandleQueryAsync<PublicKey> _getHandleActivePublicKeyQuery;

        public int BwKeySize { get; set; } = 1024;
        public string KeyCode { get; set; }
        public string KeyRef { get; set; }

        #endregion

        #region CONSTRUCTOR

        public ActivePublicKeyFromDatabaseProvider(
            IHandleQueryAsync<PublicKey> getHandleActivePublicKeyQuery)
        {
            _getHandleActivePublicKeyQuery = getHandleActivePublicKeyQuery;
            Get();
        }

        #endregion

        #region METHODS
        /// <summary>
        /// Returns active public key
        /// </summary>
        /// <returns></returns>
        public string Get()
        {
          
                //For fetching active public key 
                var publicKey = _getHandleActivePublicKeyQuery
                    .ExecuteAsync()
                    .ConfigureAwait(false)
                    .GetAwaiter()
                    .GetResult();

                KeyCode = publicKey.KeyCode;
                KeyRef = publicKey.KeyRef;

                return publicKey.Key;
           
        }
        #endregion

    }
}
