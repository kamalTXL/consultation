﻿using DialCareSaas.Core;
using DialCareSaas.Cryptography.AsymmetricKeys.Data.Queries;
using DialCareSaas.Cryptography.AsymmetricKeys.DataModel.Domain;
using DialCareSaas.Cryptography.AsymmetricKeys.Domain;
using DialCareSaas.Cryptography.AsymmetricKeys.Services.QueryHandlers;
using Microsoft.Extensions.DependencyInjection;

namespace DialCareSaas.Cryptography.AsymmetricKeys
{
    /// <summary>
    /// Extension class to inject crypto services and dependencies
    /// </summary>

    public static class AsymmetricKeyProviderExtensions
    { 

        /// <summary>
        /// Register dependencies required for Cryptography
        /// </summary>
        /// <param name="asymmetricKeys"></param>
        /// <param name="serviceCollection"></param>
        public static void RegisterDependencyForAsymmetricKeysFromDb(
          this IServiceCollection serviceCollection
        )
        {

            #region REGISTERING COMMON SERVICE DEPENDENCIES

            serviceCollection.AddScoped<ICryptAsymmetric, RsaCryptography>();
            serviceCollection.AddScoped<PublicKey>();

            #endregion

            #region REGISTERING PRIVATEKEY DEPENDENCIES

            serviceCollection.AddScoped<PrivateKey>();

            serviceCollection.AddScoped<
                IProvideAsymmetricPrivateKey,
                PrivateKeyFromDatabaseProvider>();

            serviceCollection.AddScoped<
                IExecuteDataRequestAsync<PrivateKey, string>,
                PrivateKeyByKeyRefKeyCodeQueryAsync>();

            serviceCollection.AddScoped<IHandleQueryAsync<
                PrivateKey, string>,
                PrivateKeyByKeyRefKeyCodeAsyncQueryHandler>();


            #endregion

            #region REGISTERING PUBLICKEY DEPENDENCIES
           
            serviceCollection.AddScoped<
                IExecuteDataRequestAsync<PublicKey, string>,
                PublickeyByKeyRefKeyCodeQueryAsync>();
            serviceCollection.AddScoped<
                IHandleQueryAsync<PublicKey, string>,
                PublickeyByKeyRefKeyCodeAsyncQueryHandler>();

            #endregion

            #region REGISTERING ACTIVEKEY DEPENDENCIES

                       
            serviceCollection.AddScoped<IProvideAsymmetricPublicKey, PublicKeyFromDatabaseProvider>();
            serviceCollection.AddScoped<IProvideAsymmetricPublicKey, ActivePublicKeyFromDatabaseProvider>();
            serviceCollection.AddScoped<IExecuteDataRequestAsync<PublicKey>, ActivePublicKeyQueryAsync>();
            serviceCollection.AddScoped<IHandleQueryAsync<PublicKey>, ActivePublicKeyQueryAsyncHandler>();

            #endregion            


        }     
    

    }
}
