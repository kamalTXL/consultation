﻿using DialCareSaas.Cryptography.AsymmetricKeys.Domain;
using Microsoft.EntityFrameworkCore;

namespace DialCareSaas.Cryptography.AsymmetricKeys.Data
{
    /// <summary>
    /// class for Database Connection Management
    /// </summary>
    public class DcafDbContextReadOnly : DbContext
    {        

        #region CONSTRUCTOR

        public DcafDbContextReadOnly(
            DbContextOptions<DcafDbContextReadOnly> options) : base(options)
        {
        }

        #endregion

        #region METHODS

        public DbSet<CryptographyAsymmetricKey> CryptographyAsymmetricKeys { get; set; }

        #endregion

    }
}
