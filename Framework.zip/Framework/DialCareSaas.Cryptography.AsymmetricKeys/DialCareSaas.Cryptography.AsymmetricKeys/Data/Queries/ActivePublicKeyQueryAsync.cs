﻿using DialCareSaas.Core;
using DialCareSaas.Cryptography.AsymmetricKeys.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Threading.Tasks;


namespace DialCareSaas.Cryptography.AsymmetricKeys.Data.Queries
{
    /// <summary>
    /// class to get the active public key from Database
    /// </summary>
    public class ActivePublicKeyQueryAsync : IExecuteDataRequestAsync<PublicKey>
    {

        #region PROPERTIES
        
        private readonly DcafDbContextReadOnly _dCafDbContextReadOnly;
        private readonly ILogger _logger;

        #endregion

        #region CONSTRUCTOR

        /// <summary>
        /// Constructor with dependency injection for Logger and DBContext
        /// </summary>
        /// <param name="dCafDbContextReadOnly"></param>
        public ActivePublicKeyQueryAsync(DcafDbContextReadOnly dCafDbContextReadOnly)
        {
            _dCafDbContextReadOnly = dCafDbContextReadOnly;
        }

        #endregion

        #region METHODS

        /// <summary>
        /// Gets active publick from CryptographyAsymmetricKeys table
        /// </summary>
        /// <returns></returns>
        public async Task<PublicKey> ExecuteAsync()
        {
            return await
               (from q in _dCafDbContextReadOnly
                .CryptographyAsymmetricKeys
                where q.IsActive == true
                select new PublicKey { Key = q.PublicKey, KeyCode = q.KeyCode, KeyRef = q.KeyRef })
                .FirstOrDefaultAsync<PublicKey>();
        }

        #endregion

    }
}
