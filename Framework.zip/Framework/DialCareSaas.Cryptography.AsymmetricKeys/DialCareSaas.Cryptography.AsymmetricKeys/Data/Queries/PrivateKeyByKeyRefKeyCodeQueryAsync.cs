﻿using DialCareSaas.Core;
using DialCareSaas.Cryptography.AsymmetricKeys.DataModel.Domain;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace DialCareSaas.Cryptography.AsymmetricKeys.Data.Queries
{
    /// <summary>
    /// class to get the private key from Database
    /// </summary>
    public class PrivateKeyByKeyRefKeyCodeQueryAsync : IExecuteDataRequestAsync<PrivateKey,string>
    {
        #region PROPERTIES

        private readonly DcafDbContextReadOnly _dCafDbContextReadOnly;

        #endregion

        #region CONSTRUCTOR

        /// <summary>
        /// Constructor with dependency injection for Logger and DBContext
        /// </summary>
        /// <param name="dCafDbContextReadOnly"></param>
        public PrivateKeyByKeyRefKeyCodeQueryAsync(
            DcafDbContextReadOnly dCafDbContextReadOnly)
        {
            _dCafDbContextReadOnly = dCafDbContextReadOnly;
        }

        #endregion

        #region METHODS
        /// <summary>
        /// Gets private key based on keyref and keycode
        /// </summary>
        /// <param name="privateKey"></param>
        /// <returns></returns>
        public async Task<string> ExecuteAsync(PrivateKey privateKey)
        {
            return await
               (from q in _dCafDbContextReadOnly
                .CryptographyAsymmetricKeys
                where q.KeyCode == privateKey.KeyCode && q.KeyRef == privateKey.KeyRef
                select q.PrivateKey).FirstOrDefaultAsync();
        }

        #endregion

    }
}
