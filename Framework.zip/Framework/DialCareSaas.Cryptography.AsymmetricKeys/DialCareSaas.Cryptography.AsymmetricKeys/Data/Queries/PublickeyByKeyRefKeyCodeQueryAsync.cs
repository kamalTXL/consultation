﻿using DialCareSaas.Core;
using DialCareSaas.Cryptography.AsymmetricKeys.Domain;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace DialCareSaas.Cryptography.AsymmetricKeys.Data.Queries
{
    /// <summary>
    /// class to get the public key from Database
    /// </summary>
    public class PublickeyByKeyRefKeyCodeQueryAsync : IExecuteDataRequestAsync<PublicKey,string>
    {
        #region PROPERTIES

        private readonly DcafDbContextReadOnly _dCafDbContextReadOnly;

        #endregion

        #region CONSTRUCTOR

        /// <summary>
        /// Constructor with dependency injection for Logger and DBContext
        /// </summary>
        /// <param name="dCafDbContextReadOnly"></param>
        public PublickeyByKeyRefKeyCodeQueryAsync(
                   DcafDbContextReadOnly dCafDbContextReadOnly)
        {
            _dCafDbContextReadOnly = dCafDbContextReadOnly;
        }

        #endregion

        #region METHODS
        /// <summary>
        /// Gets public key based on keyref and keycode
        /// </summary>
        /// <param name="publicKey"></param>
        /// <returns></returns>
        public async Task<string> ExecuteAsync(PublicKey publicKey)
        {
            return await
               (from q in _dCafDbContextReadOnly
                .CryptographyAsymmetricKeys
                where (q.KeyCode == publicKey.KeyCode && q.KeyRef == publicKey.KeyRef)
                select q.PublicKey).FirstOrDefaultAsync();
        }

        #endregion
    }
}
