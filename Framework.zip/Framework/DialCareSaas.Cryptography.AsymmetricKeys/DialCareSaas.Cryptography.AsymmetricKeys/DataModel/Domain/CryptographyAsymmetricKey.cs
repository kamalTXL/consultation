﻿using System.ComponentModel.DataAnnotations;

namespace DialCareSaas.Cryptography.AsymmetricKeys.Domain
{
    /// <summary>
    /// Domain Class for Asymmetric Key
    /// </summary>
    public class CryptographyAsymmetricKey 
    {
        [Key]
        public int Id { get; set; }
        public string PublicKey { get; set; }
        public string PrivateKey { get; set; }
        public string KeyRef { get; set; }
        public string KeyCode { get; set; }
        public string APIkey { get; set; }
        public bool IsActive { get; set; }
        
    }
}
