﻿namespace DialCareSaas.Cryptography.AsymmetricKeys.DataModel.Domain
{
    /// <summary>
    /// Domian Class For Private Key
    /// </summary>
    public class PrivateKey
    {
        #region Private Properties
        private string _key;
        private string _KeyRef;
        private string _KeyCode;
        #endregion

        #region Public Properties
        public string Key { get { return _key; } set { _key = string.IsNullOrWhiteSpace(value) ? null : value.Trim(); } }
        public string KeyRef { get { return _KeyRef; } set { _KeyRef = string.IsNullOrWhiteSpace(value) ? null : value.Trim(); } }
        public string KeyCode { get { return _KeyCode; } set { _KeyCode = string.IsNullOrWhiteSpace(value) ? null : value.Trim(); } }
        #endregion

    }
}
