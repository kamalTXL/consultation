﻿
namespace DialCareSaas.Cryptography.AsymmetricKeys.Domain
{
    /// <summary>
    /// Domain Class For Public Key
    /// </summary>
    public class PublicKey
    {
        #region Private Properties
        private string _key;
        private string _KeyRef;
        private string _KeyCode;
        #endregion

        #region Public Properties
        public string Key { get { return _key; } set { _key = string.IsNullOrWhiteSpace(value) ? null : value.Trim(); } }
        public string KeyRef { get { return _KeyRef; } set { _KeyRef = string.IsNullOrWhiteSpace(value) ? null : value.Trim(); } }
        public string KeyCode { get { return _KeyCode; } set { _KeyCode = string.IsNullOrWhiteSpace(value) ? null : value.Trim(); } }
        #endregion
    }
}
