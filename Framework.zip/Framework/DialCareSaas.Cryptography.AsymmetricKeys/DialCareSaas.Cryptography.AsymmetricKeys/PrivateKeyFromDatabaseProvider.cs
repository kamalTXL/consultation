﻿using DialCareSaas.Core;
using DialCareSaas.Cryptography.AsymmetricKeys.DataModel.Domain;
using Microsoft.Extensions.DependencyInjection;

namespace DialCareSaas.Cryptography.AsymmetricKeys
{
    /// <summary>
    /// Key provider class for private key
    /// </summary>
    public class PrivateKeyFromDatabaseProvider : IProvideAsymmetricPrivateKey
    {

        #region PROPERTIES

        private readonly IHandleQueryAsync<PrivateKey, string> _getHandlePrivateKeyByKeyRefKeyCodeQuery;
        public int BwKeySize { get; set; } = 1024;
        public string KeyCode { get; set; }
        public string KeyRef { get; set; }
        private static IServiceCollection services;

        #endregion

        #region CONSTRUCTOR

        public PrivateKeyFromDatabaseProvider(
           IHandleQueryAsync<PrivateKey,
           string> getHandlePrivateKeyByKeyRefKeyCodeQuery)
        {
            _getHandlePrivateKeyByKeyRefKeyCodeQuery = getHandlePrivateKeyByKeyRefKeyCodeQuery;
        }

        #endregion

        #region METHODS

        /// <summary>
        /// Returns private key
        /// </summary>
        /// <returns></returns>
        public string Get()
        {            
            return _getHandlePrivateKeyByKeyRefKeyCodeQuery
                .ExecuteAsync(new PrivateKey { KeyCode = KeyCode, KeyRef = KeyRef })
                .ConfigureAwait(false).GetAwaiter().GetResult();
        }

        #endregion

    }
}
