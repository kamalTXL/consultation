﻿using DialCareSaas.Core;
using DialCareSaas.Cryptography.AsymmetricKeys.Domain;

namespace DialCareSaas.Cryptography.AsymmetricKeys
{
    /// <summary>
    /// Key provider class for active public key
    /// </summary>
    public class PublicKeyFromDatabaseProvider : IProvideAsymmetricPublicKey
    {
        #region PROPERTIES

  
        private readonly IHandleQueryAsync<PublicKey, string> _getHandlePublicKeyByKeyRefKeyCodeQuery;

        public int BwKeySize { get; set; } = 1024;
        public string KeyCode { get; set; }
        public string KeyRef { get; set; }

        #endregion

        #region CONSTRUCTOR

        public PublicKeyFromDatabaseProvider(         
            IHandleQueryAsync<PublicKey, string> getHandlePublicKeyByKeyRefKeyCodeQuery)
        {
            _getHandlePublicKeyByKeyRefKeyCodeQuery = getHandlePublicKeyByKeyRefKeyCodeQuery;
        }

        #endregion

        #region METHODS
        /// <summary>
        /// Returns active public key when keyref and keycode is empty
        /// </summary>
        /// <returns></returns>
        public string Get()
        {
            //For fetching active public key based on KeyRef and KeyCode 

            return _getHandlePublicKeyByKeyRefKeyCodeQuery
             .ExecuteAsync(
                 new PublicKey { KeyCode = KeyCode, KeyRef = KeyRef })
             .ConfigureAwait(false).GetAwaiter().GetResult();           
        }
        
        #endregion

    }
}
