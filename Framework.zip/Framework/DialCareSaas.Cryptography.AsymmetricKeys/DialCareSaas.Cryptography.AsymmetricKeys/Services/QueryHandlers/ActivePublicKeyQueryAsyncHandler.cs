﻿using DialCareSaas.Core;
using DialCareSaas.Cryptography.AsymmetricKeys.Domain;
using System.Threading.Tasks;

namespace DialCareSaas.Cryptography.AsymmetricKeys.Services.QueryHandlers
{
    /// <summary>
    /// Query Handler class to return active public key with KeyRef and KeyCode
    /// </summary>
    public class ActivePublicKeyQueryAsyncHandler : IHandleQueryAsync<PublicKey>
    {
        #region PROPERTIES

        private readonly IExecuteDataRequestAsync<PublicKey> _getActivePublicKeyQuery;

        #endregion

        #region CONSTRUCTOR
        /// <summary>
        /// Constructor with dependency injection for Logger and DataRequest context
        /// </summary>
        /// <param name="getActivePublicKeyQuery"></param>
        public ActivePublicKeyQueryAsyncHandler(
           IExecuteDataRequestAsync<PublicKey> getActivePublicKeyQuery)
        {
            _getActivePublicKeyQuery = getActivePublicKeyQuery;
        }

        #endregion

        #region METHODS
        /// <summary>
        /// Gets  active public key query 
        /// </summary>
        /// <returns></returns>
        public async Task<PublicKey> ExecuteAsync()
        {
            return await _getActivePublicKeyQuery.ExecuteAsync();
        }

        #endregion

    }
}
