﻿using DialCareSaas.Core;
using DialCareSaas.Cryptography.AsymmetricKeys.DataModel.Domain;
using System.Threading.Tasks;

namespace DialCareSaas.Cryptography.AsymmetricKeys.Services.QueryHandlers
{
    /// <summary>
    /// Query Handler class to return private key 
    /// </summary>
    public class PrivateKeyByKeyRefKeyCodeAsyncQueryHandler : IHandleQueryAsync<PrivateKey,string>
    {
        #region PROPERTIES

        private readonly IExecuteDataRequestAsync<
            PrivateKey,
            string> _getPrivateKeyByKeyRefKeyCodeQuery;      

        #endregion

        #region CONSTRUCTOR
        /// <summary>
        /// Constructor with dependency injection for Logger and DataRequest context
        /// </summary>
        /// <param name="getPrivateKeyByKeyRefKeyCodeQuery"></param>
        public PrivateKeyByKeyRefKeyCodeAsyncQueryHandler(
            IExecuteDataRequestAsync<PrivateKey, string> getPrivateKeyByKeyRefKeyCodeQuery)
        {
           _getPrivateKeyByKeyRefKeyCodeQuery = getPrivateKeyByKeyRefKeyCodeQuery;
        }
        #endregion

        #region METHODS
        /// <summary>
        /// Gets  private key query 
        /// </summary>
        /// <param name="privateKey"></param>
        /// <returns></returns>
        public async Task<string> ExecuteAsync(PrivateKey privateKey)
        {
            return await _getPrivateKeyByKeyRefKeyCodeQuery
                .ExecuteAsync(privateKey);
        } 
        #endregion

    }
}
