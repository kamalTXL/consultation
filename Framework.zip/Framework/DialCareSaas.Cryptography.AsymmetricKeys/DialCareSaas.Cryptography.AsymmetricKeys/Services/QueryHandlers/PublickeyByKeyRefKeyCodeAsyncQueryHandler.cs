﻿using DialCareSaas.Core;
using DialCareSaas.Cryptography.AsymmetricKeys.Domain;
using System.Threading.Tasks;

namespace DialCareSaas.Cryptography.AsymmetricKeys.Services.QueryHandlers
{
    /// <summary>
    /// Query Handler class to return public key 
    /// </summary>
    public class PublickeyByKeyRefKeyCodeAsyncQueryHandler : IHandleQueryAsync<PublicKey, string>
    {

        #region PROPERTIES

        private readonly IExecuteDataRequestAsync<
            PublicKey,
            string> _getPublicKeyByKeyRefKeyCodeQuery;

        #endregion

        #region CONSTRUCTOR
        /// <summary>
        /// Constructor with dependency injection for Logger and DataRequest context
        /// </summary>
        /// <param name="getPublicKeyByKeyRefKeyCodeQuery"></param>
        /// <param name="logger"></param>
        public PublickeyByKeyRefKeyCodeAsyncQueryHandler(
            IExecuteDataRequestAsync<PublicKey, string> getPublicKeyByKeyRefKeyCodeQuery)
        {
           _getPublicKeyByKeyRefKeyCodeQuery = getPublicKeyByKeyRefKeyCodeQuery;

        }

        #endregion

        #region METHODS

        /// <summary>
        /// Gets  public key query 
        /// </summary>
        /// <param name="publicKey"></param>
        /// <returns></returns>
        public async Task<string> ExecuteAsync(PublicKey publicKey)
        {
            return await
                _getPublicKeyByKeyRefKeyCodeQuery
                .ExecuteAsync(publicKey);
        } 

        #endregion

    }
}
