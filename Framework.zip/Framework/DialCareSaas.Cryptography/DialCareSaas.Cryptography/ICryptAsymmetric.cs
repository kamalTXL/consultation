﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DialCareSaas.Cryptography
{
    public interface ICryptAsymmetric
    {

        /// <summary>
        /// Encrypts the string of data 
        /// </summary>
        /// <param name="asymmetricPublicKeyProvider">Public key provider</param>
        /// <param name="plainText">Text to encrypt</param>
        /// <param name="encoding">Encoding to use to get bytes from plain text and from encrypted bytes to encrypted text</param>
        /// <param name="fOAEP">true to perform direct System.Security.Cryptography.RSA decryption using OAEP
        ///     padding (only available on a computer running Microsoft Windows XP or later);
        ///     otherwise, false to use PKCS#1 v1.5 padding.</param>
        /// <param name="persistKeyInCsp">true if the key should be persisted in the CSP; otherwise, false.</param>
        /// <returns>string of encrypted text</returns>
        string Encrypt(IProvideAsymmetricPublicKey asymmetricPublicKeyProvider, string plainText, Encoding encoding, bool fOAEP = false, bool persistKeyInCsp = true);

        /// <summary>
        /// Encrypts the bytes of data
        /// </summary>
        /// <param name="asymmetricPublicKeyProvider">Public key provider</param>
        /// <param name="plainText">Text to encrypt</param>
        /// <param name="encoding">Encoding to use to get bytes from plain text and from encrypted bytes to encrypted text</param>
        /// <param name="fOAEP">true to perform direct System.Security.Cryptography.RSA decryption using OAEP
        ///     padding (only available on a computer running Microsoft Windows XP or later);
        ///     otherwise, false to use PKCS#1 v1.5 padding.</param>
        /// <param name="persistKeyInCsp">true if the key should be persisted in the CSP; otherwise, false.</param>
        /// <returns>bytes of encrypted data</returns>
        byte[] Encrypt(IProvideAsymmetricPublicKey asymmetricPublicKeyProvider, byte[] plainByptes, bool fOAEP = false, bool persistKeyInCsp = true);

        /// <summary>
        /// Decrypts the string of data 
        /// </summary>
        /// <param name="asymmetricPublicKeyProvider">Public key provider</param>
        /// <param name="plainText">Text to encrypt</param>
        /// <param name="encoding">Encoding to use to get bytes from plain text and from encrypted bytes to encrypted text</param>
        /// <param name="fOAEP">true to perform direct System.Security.Cryptography.RSA decryption using OAEP
        ///     padding (only available on a computer running Microsoft Windows XP or later);
        ///     otherwise, false to use PKCS#1 v1.5 padding.</param>
        /// <param name="persistKeyInCsp">true if the key should be persisted in the CSP; otherwise, false.</param>
        /// <returns>string of encrypted data</returns>
        string Decrypt(IProvideAsymmetricPrivateKey asymmetricPublicKeyProvider, string plainText, Encoding encoding, bool fOAEP = false, bool persistKeyInCsp = true);

        /// <summary>
        /// Decrypts the bytes of data 
        /// </summary>
        /// <param name="asymmetricPublicKeyProvider">Public key provider</param>
        /// <param name="plainText">Text to encrypt</param>
        /// <param name="encoding">Encoding to use get bytes from plain text and from encrypted bytes to encrypted text</param>
        /// <param name="fOAEP">true to perform direct System.Security.Cryptography.RSA decryption using OAEP
        ///     padding (only available on a computer running Microsoft Windows XP or later);
        ///     otherwise, false to use PKCS#1 v1.5 padding.</param>
        /// <param name="persistKeyInCsp">true if the key should be persisted in the CSP; otherwise, false.</param>
        /// <returns>bytes of decrypted data</returns>
        byte[] Decrypt(IProvideAsymmetricPrivateKey asymmetricPublicKeyProvider, byte[] plainByptes, bool fOAEP = false, bool persistKeyInCsp = true);

    }
}
