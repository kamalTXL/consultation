﻿using System;

namespace DialCareSaas.Cryptography
{
    public interface IProvideAsymmetricKeys
    {
        /// <summary>
        /// Gets or sets the key code used for this key
        /// </summary>
        string KeyCode { get; set; }
        /// <summary>
        /// Gets or sets the key reference used for this key
        /// </summary>
        string KeyRef { get; set; }
        /// <summary>
        /// Gets or sets the size of the key, like 1024, 2048 etc.
        /// </summary>
        int BwKeySize { get; set; }
        /// <summary>
        /// Implement this to return the public/private key from your prefered store (file, X509 cert, database etc.)
        /// </summary>
        /// <returns>public or private XML formated RSA key string</returns>
        string Get();
    }
}