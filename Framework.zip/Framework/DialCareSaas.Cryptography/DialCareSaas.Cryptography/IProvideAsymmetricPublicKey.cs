﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DialCareSaas.Cryptography
{
    public interface IProvideAsymmetricPublicKey : IProvideAsymmetricKeys { }
}
