﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DialCareSaas.Cryptography
{
    public class PrivateKeysFromXmlFile : IProvideAsymmetricPrivateKey
    {
        private readonly string _privateKeyPath;
        public PrivateKeysFromXmlFile(string privateKeyPath, string keyCode, string keyRef)
        {
            if (string.IsNullOrWhiteSpace(privateKeyPath))
                throw new ArgumentNullException(nameof(privateKeyPath));
            if (!File.Exists(privateKeyPath))
                throw new InvalidDataException($"File name doesn't exists or access is denied: {privateKeyPath}");

            _privateKeyPath = privateKeyPath;
            KeyCode = keyCode;
            KeyRef = keyRef;
        }

        public int BwKeySize { get; set; } = 1024;
        public string KeyCode { get; set; }
        public string KeyRef { get; set; }

        public string Get()
        {
            // Open the text file using a stream reader.
            using (StreamReader sr = new StreamReader(_privateKeyPath))
            {
                // Read the stream to a string, and write the string to the console.
                return sr.ReadToEnd();
            }
        }

    }
}
