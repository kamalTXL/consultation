﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DialCareSaas.Cryptography
{
    public class PublicKeysFromXmlFile : IProvideAsymmetricPublicKey
    {
        private readonly string _publicKeyPath;
        public PublicKeysFromXmlFile(string publicKeyPath, string keyCode, string keyRef)
        {
            if (string.IsNullOrWhiteSpace(publicKeyPath))
                throw new ArgumentNullException(nameof(publicKeyPath));
            if (!File.Exists(publicKeyPath))
                throw new InvalidDataException($"File name doesn't exists or access is denied: {publicKeyPath}");

            _publicKeyPath = publicKeyPath;
            KeyCode = keyCode;
            KeyRef = keyRef;
        }

        public int BwKeySize { get; set; } = 1024;
        public string KeyCode { get; set; }
        public string KeyRef { get; set; }

        public string Get()
        {
            // Open the text file using a stream reader.
            using (StreamReader sr = new StreamReader(_publicKeyPath))
            {
                // Read the stream to a string, and write the string to the console.
                return sr.ReadToEnd();
            }
        }

    }
}
