﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace DialCareSaas.Cryptography
{
    public class RsaCryptography : ICryptAsymmetric
    {
        public string Decrypt(IProvideAsymmetricPrivateKey asymmetricPrivateKeyProvider, string decryptedText, Encoding encoding, bool fOAEP = false, bool persistKeyInCsp = true)
        {
            byte[] encryptedEncodedBytes = HexEncoding.GetBytes(decryptedText, out int discarded);
            string utf8EncodedString = Encoding.UTF8.GetString(encryptedEncodedBytes);
            byte[] encryptedBytes = encoding.GetBytes(utf8EncodedString);

            byte[] plainBytes = Decrypt(asymmetricPrivateKeyProvider, encryptedBytes, fOAEP, persistKeyInCsp);
            return ConvertToText(plainBytes, encoding);
        }

        public byte[] Decrypt(IProvideAsymmetricPrivateKey asymmetricPrivateKeyProvider, byte[] encryptedBytes, bool fOAEP = false, bool persistKeyInCsp = true)
        {
            using (var rsa = new RSACryptoServiceProvider(asymmetricPrivateKeyProvider.BwKeySize))
            {
                RSACryptoServiceProvider.UseMachineKeyStore = true;
                try
                {
                    rsa.FromXmlString(asymmetricPrivateKeyProvider.Get());
                    return rsa.Decrypt(encryptedBytes, fOAEP);
                }
                finally
                {
                    rsa.PersistKeyInCsp = persistKeyInCsp;
                }
            }
        }

        public string Encrypt(IProvideAsymmetricPublicKey asymmetricPublicKeyProvider, string plainText, Encoding encoding, bool fOAEP=false, bool persistKeyInCsp = true)
        {
            string encryptedText = null;
            do
            {
                byte[] encryptedBytes = Encrypt(asymmetricPublicKeyProvider, encoding.GetBytes(plainText), fOAEP, persistKeyInCsp);
                encryptedText = ConvertToText(encryptedBytes, encoding);
            } while (encryptedText.Length != 128);
            Byte[] utf8EncodedBytes = Encoding.UTF8.GetBytes(encryptedText);
            return HexEncoding.ToString(utf8EncodedBytes);
        }

        public byte[] Encrypt(IProvideAsymmetricPublicKey asymmetricPublicKeyProvider, byte[] plainByptes, bool fOAEP=false, bool persistKeyInCsp=true)
        {
            using (var rsa = new RSACryptoServiceProvider(asymmetricPublicKeyProvider.BwKeySize))
            {
                RSACryptoServiceProvider.UseMachineKeyStore = true;
                try
                {
                    rsa.FromXmlString(asymmetricPublicKeyProvider.Get());
                    return rsa.Encrypt(plainByptes, fOAEP);
                }
                finally
                {
                    rsa.PersistKeyInCsp = persistKeyInCsp;
                }
            }
        }

        //******************************** THIS IS COPY FROM OLD CODE. WE NEED TO STICK TO THIS WAY TO SUPPORT THE EXISTING DECRYPTED DATA *********************************************//
        private string ConvertToText(byte[] bytes, Encoding encoding)
        {
            int i = Array.IndexOf(bytes, ((byte)(0)));
            if (i >= 0)
            {
                return encoding.GetString(bytes, 0, i);
            }
            else
            {
                return encoding.GetString(bytes);
            }
        }

    }
}
