﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Data
{
    public interface IIdentifiable<T> where T : IEquatable<T>
    {
        T Id { get; set; }
    }
}
