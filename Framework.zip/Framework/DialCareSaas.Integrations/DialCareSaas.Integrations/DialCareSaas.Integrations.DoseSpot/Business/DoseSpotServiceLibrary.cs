﻿using DialCareSaas.Integrations.DoseSpot.Business.Implementations;
using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;
using Microsoft.Extensions.DependencyInjection;

namespace DialCareSaas.Integrations.DoseSpot.Business
{
    public static class DoseSpotServiceLibrary
    {
        public static void RegisterDoseSpotServiceLibrary(this IServiceCollection service)
        {
            service.AddScoped<IClinicians, CliniciansData>();
            service.AddScoped<IPatients, PatientsData>();

            service.AddScoped<IPatientEdit, PatientsDataEdit>();
            service.AddScoped<IPatientsSave, PatientsDataSave>();
            service.AddScoped<IProviderSave, ProviderDataSave>();
            service.AddScoped<IProviderEdit, ProviderDataEdit>();
            service.AddScoped<IPatientPrescriptions, PatientPrescriptionsDetails>();
            service.AddScoped<IDoseSpotSSOURL, DoseSpotSSOURL>();
            service.AddScoped<IPharmacy, PharmacyData>();
            service.AddScoped<IPharmacySave, PharmacyDataSave>();
            service.AddScoped<IToken, TokenService>();
            service.AddSingleton<IEncryptionHelper, EncryptionHelper>();
            service.AddScoped<IApiCall<string>, ApiCall<string>>();
            service.AddScoped<IApiCall<ClinicianRequestModel>, ApiCall<ClinicianRequestModel>>();
            service.AddScoped<IApiCall<PatientRequest>, ApiCall<PatientRequest>>();
            service.AddScoped<IApiCall<ClinicianRequestModelEdit>, ApiCall<ClinicianRequestModelEdit>>();
            service.AddScoped<IApiCall<PharmacyPostRequest>, ApiCall<PharmacyPostRequest>>();
        }
    }
}
