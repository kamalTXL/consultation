﻿using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Business.Extensions
{
    public static class WebClientExtensions
    {
        
        public static async Task<TokenResponse> BuildRequestAuthorization(DoseSpotHelperModel options)
        {
            TokenResponse tokenResponse = new TokenResponse();

            IEncryptionHelper obj = new EncryptionHelper();
            LoginKeys keys = obj.GetLoginKeys(options);

            TokenRequest request = new TokenRequest();
            request.grant_type = "password";
            request.Username = options.SupervisorId;
            request.Password = keys.EncryptedUserId;

            //setup reusable http client
            HttpClient client = new HttpClient();
            Uri baseUri = new Uri(options.DoseSpotBaseURL);
            client.BaseAddress = baseUri;
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.ConnectionClose = true;

            //Post body content
            var values = new List<KeyValuePair<string, string>>();
            values.Add(new KeyValuePair<string, string>("grant_type", request.grant_type));
            values.Add(new KeyValuePair<string, string>("Username", request.Username));
            values.Add(new KeyValuePair<string, string>("Password", request.Password));
            var content = new FormUrlEncodedContent(values);
            var authenticationString = $"{options.ClinicId}:{keys.EncryptedClinicId}";
            var base64EncodedAuthenticationString = Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(authenticationString));
            
            //generating token
            var requestMessage = new HttpRequestMessage(HttpMethod.Post, "/webapi/token");
            requestMessage.Headers.Authorization = new AuthenticationHeaderValue("Basic", base64EncodedAuthenticationString);
            requestMessage.Content = content;

            //make the request
            try
            {
                var response = await client.SendAsync(requestMessage);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(responseBody);
                if (tokenResponse != null)
                {
                    tokenResponse.Success = true;
                }
            }
            catch (Exception ex)
            {
                tokenResponse.Success = false;               
            }

            return tokenResponse;
        }
    }
}
