﻿using DialCareSaas.Integrations.DoseSpot.Business.Extensions;
using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;

namespace DialCareSaas.Integrations.DoseSpot.Business.Implementations
{
    public class CliniciansData : IClinicians
    {
        private readonly DoseSpotHelperModel _options;

        public CliniciansData(DoseSpotHelperModel options)
        {
            _options = options;
        }
        public async Task<string> GetClinicians(string id)
        {
            TokenResponse tokenResponse = new TokenResponse();
            tokenResponse = await WebClientExtensions.BuildRequestAuthorization(_options);
            string url = "/webapi/api/clinicians/" + id;
            return await ApiHelperClass<string>.GetAsync(url, tokenResponse.access_token, _options.DoseSpotBaseURL);           
        }
    }
}
