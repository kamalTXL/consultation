﻿using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;

namespace DialCareSaas.Integrations.DoseSpot.Business.Implementations
{
    public class DoseSpotClient : IDoseSpotClient
    {
        public IClinicians clinicians { get; }

        public IDoseSpotSSOURL doseSpotSSOURL { get; }

        public IPatientPrescriptions prescriptions { get; }

        public IPatients patients { get; }

        public IPharmacy pharmacy { get; }

        public IProviderSave providerSave { get; }

        public IProviderEdit providerEdit { get; }

        public IPatientsSave patientsSave { get; }

        public IPatientEdit patientEdit { get; }

        public IPharmacySave pharmacySave { get; }

        public DoseSpotClient(DoseSpotHelperModel options)
        {
            clinicians = new CliniciansData(options);

            prescriptions = new PatientPrescriptionsDetails(options);

            patients = new PatientsData(options);

            pharmacy = new PharmacyData(options);

            providerSave = new ProviderDataSave(options);

            providerEdit = new ProviderDataEdit(options);

            patientsSave = new PatientsDataSave(options);

            patientEdit = new PatientsDataEdit(options);

            doseSpotSSOURL = new DoseSpotSSOURL(options);

            pharmacySave = new PharmacyDataSave(options);
            pharmacySave = new PharmacyDataSave(options);

        }
    }
}
