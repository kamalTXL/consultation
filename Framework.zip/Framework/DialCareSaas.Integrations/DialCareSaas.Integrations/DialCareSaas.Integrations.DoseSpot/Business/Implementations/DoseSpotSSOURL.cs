﻿using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;
using System.Text;
using System.Web;

namespace DialCareSaas.Integrations.DoseSpot.Business.Implementations
{
    public class DoseSpotSSOURL : IDoseSpotSSOURL
    {
        private readonly DoseSpotHelperModel _options;
        public DoseSpotSSOURL(DoseSpotHelperModel options)
        {             
            _options = options;
        }
        public string GetDoseSpotSSOURL(string DoseSpotProviderID, string DoseSpotPatientID)
        {
            EncryptionHelper _encryptionHelper= new EncryptionHelper();
            var loginKeys = _encryptionHelper.GetLoginKeys(_options);            
            var baseURL = _options.DoseSpotBaseURL;
            StringBuilder sb = new StringBuilder();
            sb.Append(baseURL);
            sb.Append("/LoginSingleSignOn.aspx?SingleSignOnClinicId=");
            sb.Append(_options.ClinicId);
            sb.Append("&SingleSignOnUserId=");
            sb.Append(DoseSpotProviderID);
            sb.Append("&PatientId=");
            sb.Append(DoseSpotPatientID);
            sb.Append("&OnBehalfOfUserId=");
            sb.Append(DoseSpotProviderID);
            sb.Append("&EncounterID=0&SingleSignOnSupervisorId=");
            sb.Append(_options.SupervisorId);
            sb.Append("&SingleSignOnPhraseLength=32&SingleSignOnCode=");
            sb.Append(HttpUtility.UrlEncode(loginKeys.EncryptedClinicId));
            sb.Append("&SingleSignOnUserIdVerify=");
            sb.Append(HttpUtility.UrlEncode(loginKeys.EncryptedUserId));           
          
            return sb.ToString();
        }
    }
}
