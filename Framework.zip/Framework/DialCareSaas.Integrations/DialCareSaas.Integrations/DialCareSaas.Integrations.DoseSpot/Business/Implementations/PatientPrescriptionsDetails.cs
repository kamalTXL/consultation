﻿using DialCareSaas.Integrations.DoseSpot.Business.Extensions;
using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;


namespace DialCareSaas.Integrations.DoseSpot.Business.Implementations
{
    public class PatientPrescriptionsDetails : IPatientPrescriptions
    {
      //  private readonly IApiCall<string> objcall;

        //public PatientPrescriptionsDetails(IApiCall<string> apiCall)
        //{
        //    objcall = apiCall;
        //}

        private readonly DoseSpotHelperModel _options;
        public PatientPrescriptionsDetails(DoseSpotHelperModel options)
        {
            _options = options;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<string> GetPatientPrescriptions(int id, string startDate, string endDate)
        {
            // string url = ($"/webapi/api/patients/{id}/prescriptions?startDate={startDate}&endDate={endDate}");           
            // return await objcall.GetAsync(url);

            TokenResponse tokenResponse = new TokenResponse();
            tokenResponse = await WebClientExtensions.BuildRequestAuthorization(_options);
            string url = ($"/webapi/api/patients/{id}/prescriptions?startDate={startDate}&endDate={endDate}");
            return await ApiHelperClass<string>.GetAsync(url, tokenResponse.access_token, _options.DoseSpotBaseURL);

        }

    }
}
