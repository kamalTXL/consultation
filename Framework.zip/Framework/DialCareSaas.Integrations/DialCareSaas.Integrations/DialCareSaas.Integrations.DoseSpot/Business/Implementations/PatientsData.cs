﻿using DialCareSaas.Integrations.DoseSpot.Business.Extensions;
using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;

namespace DialCareSaas.Integrations.DoseSpot.Business.Implementations
{
    public class PatientsData : IPatients
    {
        //private readonly IApiCall<string> objcall;
        //public PatientsData(IApiCall<string> apiCall)
        //{
        //    objcall = apiCall;
        //}

        private readonly DoseSpotHelperModel _options;
        public PatientsData(DoseSpotHelperModel options)
        {
            _options = options;
        }

        public async Task<string> GetPatientDetailById(string DoseSpot_PatientID)
        {
            //string url = "/webapi/api/patients/" + DoseSpot_PatientID + "/details";     
            //return await objcall.GetAsync(url);
            
            TokenResponse tokenResponse = new TokenResponse();
            tokenResponse = await WebClientExtensions.BuildRequestAuthorization(_options);
            string url = "/webapi/api/patients/" + DoseSpot_PatientID + "/details";
            return await ApiHelperClass<string>.GetAsync(url, tokenResponse.access_token, _options.DoseSpotBaseURL);

        }
    }
}
