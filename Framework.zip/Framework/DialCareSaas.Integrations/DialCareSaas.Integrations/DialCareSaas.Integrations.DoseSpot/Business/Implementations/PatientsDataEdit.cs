﻿using DialCareSaas.Integrations.DoseSpot.Business.Extensions;
using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;

namespace DialCareSaas.Integrations.DoseSpot.Business.Implementations
{
    public class PatientsDataEdit : IPatientEdit
    {
        //private readonly IApiCall<PatientRequest> objcall;
        //public PatientsDataEdit(IApiCall<PatientRequest> apiCall)
        //{
        //    objcall = apiCall;
        //}

        private readonly DoseSpotHelperModel _options;
        public PatientsDataEdit(DoseSpotHelperModel options) 
        {
            _options = options;
        }

        public async Task<string> EditPatient(string patientId, PatientRequest patients)
        {
            // string url = "/webapi/api/patients/" + patientId;
            //return await objcall.PostAsync(url, patients);

            TokenResponse tokenResponse = new TokenResponse();
            tokenResponse = await WebClientExtensions.BuildRequestAuthorization(_options);
            string url = "/webapi/api/patients/" + patientId;
            return await ApiHelperClass<PatientRequest>.PostAsync(url,patients, tokenResponse.access_token, _options.DoseSpotBaseURL);

        }

    }
}
