﻿using DialCareSaas.Integrations.DoseSpot.Business.Extensions;
using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;


namespace DialCareSaas.Integrations.DoseSpot.Business.Implementations
{
    public class PatientsDataSave : IPatientsSave
    {
        //private readonly IApiCall<PatientRequest> objcall;
        //public PatientsDataSave(IApiCall<PatientRequest> apiCall) 
        //{
        //    objcall = apiCall;
        //}

        private readonly DoseSpotHelperModel _options;
        public PatientsDataSave(DoseSpotHelperModel options) 
        {
            _options = options;
        }

        public async Task<string> PatientsSave(PatientRequest patientRequest)
        {
            // string url = "/webapi/api/patients/";
            // return await objcall.PostAsync(url, patientRequest);       

            TokenResponse tokenResponse = new TokenResponse();
            tokenResponse = await WebClientExtensions.BuildRequestAuthorization(_options);
            string url = "/webapi/api/patients/";
            return await ApiHelperClass<PatientRequest>.PostAsync(url, patientRequest, tokenResponse.access_token, _options.DoseSpotBaseURL);
        }
    }
}
