﻿using DialCareSaas.Integrations.DoseSpot.Business.Extensions;
using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;


namespace DialCareSaas.Integrations.DoseSpot.Business.Implementations
{
    public class PharmacyData : IPharmacy
    {
        private readonly DoseSpotHelperModel _options;
        public PharmacyData(DoseSpotHelperModel options) 
        {
            _options = options;
        }

        public async Task<string> SearchPharmacy(string url) 
        {

            TokenResponse tokenResponse = new TokenResponse();
            tokenResponse = await WebClientExtensions.BuildRequestAuthorization(_options);
            return await ApiHelperClass<string>.GetAsync(url, tokenResponse.access_token, _options.DoseSpotBaseURL);
        }

 
    }
}
