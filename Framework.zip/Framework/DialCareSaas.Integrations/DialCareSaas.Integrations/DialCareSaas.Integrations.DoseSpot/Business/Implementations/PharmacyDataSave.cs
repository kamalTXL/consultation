﻿using DialCareSaas.Integrations.DoseSpot.Business.Extensions;
using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;
using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace DialCareSaas.Integrations.DoseSpot.Business.Implementations
{
    public class PharmacyDataSave : IPharmacySave
    {
        //private readonly IApiCall<PharmacyPostRequest> objcall;
        //public PharmacyDataSave(IApiCall<PharmacyPostRequest> apiCall) 
        //{
        //    objcall = apiCall;
        //}
        private readonly DoseSpotHelperModel _options;
        public PharmacyDataSave(DoseSpotHelperModel options)
        {
            _options = options;
        }

        public async Task<string> SavePharmacy(string? DoseSpot_PatientID, int PharmacyId, bool SetAsPrimary)
        {
            //string url = "webapi/api/patients/" + DoseSpot_PatientID + "/pharmacies/" + PharmacyId.ToString();
            //PharmacyPostRequest data = new PharmacyPostRequest();
            //data.SetAsPrimary = SetAsPrimary;
            //return await objcall.PostAsync(url, data);
             TokenResponse tokenResponse = new TokenResponse();
            tokenResponse = await WebClientExtensions.BuildRequestAuthorization(_options);
            string url = "webapi/api/patients/" + DoseSpot_PatientID + "/pharmacies/" + PharmacyId.ToString();
            PharmacyPostRequest data = new PharmacyPostRequest();
            data.SetAsPrimary = SetAsPrimary;
            string searlizedData= JsonConvert.SerializeObject(data);
            return await ApiHelperClass<string>.PostAsync(url, searlizedData, tokenResponse.access_token, _options.DoseSpotBaseURL);
        }
    }
}
