﻿using DialCareSaas.Integrations.DoseSpot.Business.Extensions;
using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;

namespace DialCareSaas.Integrations.DoseSpot.Business.Implementations
{
    public class ProviderDataEdit : IProviderEdit
    {

        private readonly DoseSpotHelperModel _options;
        public ProviderDataEdit(DoseSpotHelperModel options)
        {
            _options = options; 
        }

        public async Task<string> EditProvider(int id, ClinicianRequestModelEdit clinician)
        {
            //string url = "/webapi/api/clinicians/" + clinician.ClinicianId;
            //return await objcall.PostAsync(url, clinician);

            TokenResponse tokenResponse = new TokenResponse();
            tokenResponse = await WebClientExtensions.BuildRequestAuthorization(_options);
            string url = "/webapi/api/clinicians/" + clinician.ClinicianId;
            return await ApiHelperClass<ClinicianRequestModelEdit>.PostAsync(url, clinician, tokenResponse.access_token, _options.DoseSpotBaseURL);
        }
    }
}
