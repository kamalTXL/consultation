﻿using DialCareSaas.Integrations.DoseSpot.Business.Extensions;
using DialCareSaas.Integrations.DoseSpot.Business.Interfaces;
using DialCareSaas.Integrations.DoseSpot.Core.Models;
using DialCareSaas.Integrations.DoseSpot.Data;

namespace DialCareSaas.Integrations.DoseSpot.Business.Implementations
{
    public class ProviderDataSave : IProviderSave
    {
        //private readonly IApiCall<ClinicianRequestModel> objcall;
        //public ProviderDataSave(IApiCall<ClinicianRequestModel> apiCall)
        //{
        //    objcall = apiCall;
        //}

        private readonly DoseSpotHelperModel _options;
        public ProviderDataSave(DoseSpotHelperModel options) 
        {
            _options = options;
        }
        public async Task<string> SaveProvider(ClinicianRequestModel clinician)
        {
            //string url = "/webapi/api/clinicians";
            //return await objcall.PostAsync(url, clinician);

            TokenResponse tokenResponse = new TokenResponse();
            tokenResponse = await WebClientExtensions.BuildRequestAuthorization(_options);
            string url = "/webapi/api/clinicians";
            return await ApiHelperClass<ClinicianRequestModel>.PostAsync(url, clinician, tokenResponse.access_token, _options.DoseSpotBaseURL);
        }
    }
}
