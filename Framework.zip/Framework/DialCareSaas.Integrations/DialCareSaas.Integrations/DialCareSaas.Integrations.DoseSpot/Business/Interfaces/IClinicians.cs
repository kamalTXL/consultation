﻿namespace DialCareSaas.Integrations.DoseSpot.Business.Interfaces
{
    public interface IClinicians
    {
        Task<string> GetClinicians(string id);

    }
}

//namespace DialCareSaas.Integrations.DoseSpot.Business.Interfaces
//{
//    public interface IClinicians
//    {
//        Task<string> GetClinicians(string id);

//    }
//}
