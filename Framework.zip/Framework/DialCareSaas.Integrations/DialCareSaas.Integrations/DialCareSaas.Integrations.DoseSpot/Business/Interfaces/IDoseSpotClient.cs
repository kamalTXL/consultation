﻿
namespace DialCareSaas.Integrations.DoseSpot.Business.Interfaces
{
    public interface IDoseSpotClient
    {
        IClinicians clinicians { get; }
        IDoseSpotSSOURL doseSpotSSOURL { get; }
        IPatientPrescriptions prescriptions { get; }
        IPatients patients { get; }
        IPharmacy pharmacy { get; }
        IProviderSave providerSave { get; }
        IProviderEdit providerEdit { get; }
        IPatientsSave patientsSave { get; }
        IPatientEdit patientEdit { get; }
        IPharmacySave pharmacySave { get; }
    }
}
