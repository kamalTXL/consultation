﻿namespace DialCareSaas.Integrations.DoseSpot.Business.Interfaces
{
    public interface IDoseSpotSSOURL  
    {
        string GetDoseSpotSSOURL(string DoseSpotProviderID, string DoseSpotPatientID);  

    }
}
