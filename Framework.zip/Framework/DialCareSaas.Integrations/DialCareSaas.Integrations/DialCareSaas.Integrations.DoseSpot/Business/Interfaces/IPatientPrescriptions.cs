﻿using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Business.Interfaces
{
    public interface IPatientPrescriptions
    {
        Task<string> GetPatientPrescriptions(int id, string startDate, string endDate);
    }

}
