﻿using DialCareSaas.Integrations.DoseSpot.Core.Models;

namespace DialCareSaas.Integrations.DoseSpot.Business.Interfaces
{
    public interface IPatients
    {
        Task<string> GetPatientDetailById(string id);

    }
    public interface IPatientsSave 
    {
        Task<string> PatientsSave (PatientRequest patientRequest);

    }
    public interface IPatientEdit
    {
        Task<string> EditPatient(string patientId, PatientRequest patients);
    }
}
