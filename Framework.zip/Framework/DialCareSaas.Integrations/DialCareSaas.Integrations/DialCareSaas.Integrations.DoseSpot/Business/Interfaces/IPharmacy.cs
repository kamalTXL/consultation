﻿namespace DialCareSaas.Integrations.DoseSpot.Business.Interfaces
{
    public interface IPharmacy
    {
        Task<string> SearchPharmacy(string url);
        
    }

    public interface IPharmacySave 
    {
        Task<string> SavePharmacy(string? DoseSpot_PatientID, int PharmacyId, bool SetAsPrimary); 
    }
}
