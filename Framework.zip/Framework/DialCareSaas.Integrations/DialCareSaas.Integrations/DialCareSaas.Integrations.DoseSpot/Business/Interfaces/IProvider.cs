﻿using DialCareSaas.Integrations.DoseSpot.Core.Models;

namespace DialCareSaas.Integrations.DoseSpot.Business.Interfaces
{
    public interface IProviderSave 
    {
        Task<string> SaveProvider(ClinicianRequestModel clinician);

    }
    public interface IProviderEdit 
    {
        Task<string> EditProvider(int id, ClinicianRequestModelEdit clinician); 

    }
}
