﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class DoseSpotClinic
    {
        public string ClinicName { get; set; } = null!;
        public int ClinicID { get; set; }
        public string? SupervisorId { get; set; }
        public string ClinicKey { get; set; } = null!;
        public string? Address { get; set; } = null!;
        public int? PhoneNumber { get; set; }
        public bool? IsActive { get; set; } = false;
        public int Id { get; set; }
        public string CreatedBy { get; set; } = "System";
        public string UpdatedBy { get; set; } = "System";
        public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedOn { get; set; } = DateTime.UtcNow;
    }

    public class DoseSpotClinicResponse 
    {
        public DoseSpotClinic result { get; set; }
        public dynamic errors { get; set; }
    }
}
