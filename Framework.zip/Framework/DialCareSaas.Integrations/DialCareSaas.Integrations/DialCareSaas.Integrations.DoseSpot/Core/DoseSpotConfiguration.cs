﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class DoseSpotConfiguration
    {
        public int ID { get; set; }
        public string ForClientId { get; set; }
        public string ForUserId { get; set; }
        public string ClinicKey { get; set; }
        public string ClinicId { get; set; }
        public string SupervisorId { get; set; }
        public string DoseSpotUrl { get; set; }

    }
}
