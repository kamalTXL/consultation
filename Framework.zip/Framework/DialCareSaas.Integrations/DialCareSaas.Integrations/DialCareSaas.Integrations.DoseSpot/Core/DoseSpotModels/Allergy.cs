﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class Allergy 
    {
      public int? PatientAllergyId { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }
        public int? RxCUI { get; set; }
        public int? CodeType { get; set; }
        public string? Reaction { get; set; }
        public int? ReactionType { get; set; }
        public int? StatusType { get; set; }
        public DateTime? OnsetDate { get; set; }
        public int? LastUpdatedUserId { get; set; }

    }
}
