﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class Clinic
    {
        public int? ClinicId { get; set; }
        public string? ClinicName { get; set; }
        public string? ClinicNameLongForm { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public bool? Active { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? ZipCode { get; set; }
        public string? PrimaryPhone { get; set; }
        public int? PrimaryPhoneType { get; set; }
        public string? PrimaryFax { get; set; }
        public string? PhoneAdditional1 { get; set; }
        public int? PhoneAdditionalType1 { get; set; }
        public string? PhoneAdditional2 { get; set; }
        public int? PhoneAdditionalType2 { get; set; }
        public string? PhoneAdditional3 { get; set; }
        public int? PhoneAdditionalType3 { get; set; }
    }
}
