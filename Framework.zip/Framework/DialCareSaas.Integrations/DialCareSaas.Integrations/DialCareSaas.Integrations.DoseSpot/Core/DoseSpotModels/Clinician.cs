﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class Clinician
    {
        public string? Prefix { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string? MiddleName { get; set; }
        public string LastName { get; set; } = string.Empty;
        public string? Suffix { get; set; }
        public DateTime DateOfBirth { get; set; } = DateTime.MinValue;
        public string Email { get; set; } = string.Empty;
        public string Address1 { get; set; } = string.Empty;
        public string Address2 { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        public string State { get; set; } = string.Empty;
        public int ZipCode { get; set; } = 0;
        public string PrimaryPhone { get; set; } = string.Empty;
        public int PrimaryPhoneType { get; set; } = 0;
        public string? PrimaryFax { get; set; } = string.Empty;
        public string? PhoneAdditional1 { get; set; }
        public int? PhoneAdditionalType1 { get; set; }
        public string? PhoneAdditional2 { get; set; }
        public int? PhoneAdditionalType2 { get; set; }
        public string? PhoneAdditional3 { get; set; }
        public int? PhoneAdditionalType3 { get; set; }
        public List<DEANumbers>? DEANumbers { get; set; } //DEANumber, State, ClinicId
        public List<NADEANumbers>? NADEANumbers { get; set; }  //NADEANumber, State, ClinicId
        public List<MedicalLicenseNumber>? MedicalLicenseNumbers { get; set; } //LicenceNumber, State, ClinicId
        public string? NPINumber { get; set; }
        public int[]? ClinicianRoleType { get; set; }
        public Boolean? Active { get; set; }
        public Boolean? EpcsRequested { get; set; }
    }

   
}
