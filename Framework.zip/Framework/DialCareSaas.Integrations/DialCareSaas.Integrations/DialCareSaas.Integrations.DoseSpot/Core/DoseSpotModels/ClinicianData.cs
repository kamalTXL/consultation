﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class ClinicianData
    {
        public int? ClinicianId { get; set; }
        public string? Prefix { get; set; }
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }
        public string? Suffix { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? Email { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public int? ZipCode { get; set; }
        public string? PrimaryPhone { get; set; }
        public string? PrimaryPhoneType { get; set; }
        public string? PrimaryFax { get; set; }
        public string? PhoneAdditional1 { get; set; }
        public int? PhoneAdditionalType1 { get; set; }
        public string? PhoneAdditional2 { get; set; }
        public int? PhoneAdditionalType2 { get; set; }
        public string? PhoneAdditional3 { get; set; }
        public int? PhoneAdditionalType3 { get; set; }
        public List<DEANumbers>? DEANumbers { get; set; }
        public string? DEANumber { get; set; }
        public NADEANumbers[]? NADEANumbers { get; set; }
        public List<MedicalLicenseNumber>? MedicalLicenseNumbers { get; set; }
        public string? NPINumber { get; set; }
        public int[]? Roles { get; set; }
        public int? PDMPRoleType { get; set; }
        public Boolean? Confirmed { get; set; }
        public Boolean? Active { get; set; }
        public Boolean? EpcsRequested { get; set; }
        public List<ClinicInfo>? ClinicInfo { get; set; }
    }

    public class DEANumbers
    {
        public string? DEANumber { get; set; }
        public string? State { get; set; }
        public string? ClinicId { get; set; }
    }
    public class NADEANumbers
    {
        public string? NADEANumber { get; set; }
        public string? State { get; set; }
        public string? ClinicId { get; set; }
    }

    public class MedicalLicenseNumber
    {
        public string? LicenseNumber { get; set; }
        public string? State { get; set; }
        public string? ClinicId { get; set; }
    }

    public class ClinicInfo
    {
        public int? ClinicId { get; set; }
        public Boolean? HasNewRx { get; set; }
        public Boolean? HasRefills { get; set; }
        public Boolean? HasRxChange { get; set; }
        public Boolean? HasCancel { get; set; }
        public Boolean? HasRxFill { get; set; }
        public Boolean? HasEpcs { get; set; }
    }
}
