﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class ClinicianRequestModel
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? Email { get; set; }
        public string? Address1 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? ZipCode { get; set; }

        public string? PrimaryPhone { get; set; }
        public string? PrimaryPhoneType { get; set; }
        public string? PrimaryFax { get; set; }
        public List<DEANumbers1>? DEANumbers { get; set; }
        public string? NPINumber { get; set; }
        public int[]? ClinicianRoleType { get; set; }
        public bool? Active { get; set; }
        public bool? EPCSRequested { get; set; } = false;

    }
    public class DEANumbers1
    {
        public string? DEANumber { get; set; }
        public string? State { get; set; }
    }
    public class ClinicianRequestModelEdit:ClinicianRequestModel
    {
        public int ClinicianId { get; set; }
    }
}
