﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class ClinicianResponse
    {
        public ClinicianData? Item { get; set; }
        public Result? Result { get; set; }
    }
  
}
