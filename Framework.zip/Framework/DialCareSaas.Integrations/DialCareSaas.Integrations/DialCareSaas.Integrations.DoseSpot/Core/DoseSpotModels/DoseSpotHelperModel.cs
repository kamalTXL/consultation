﻿using System.Reflection.Metadata.Ecma335;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class DoseSpotHelperModel
    {
        public string ClinicKey { get; set; } = null!;
        public string ClinicId { get; set; } = null!;
        public string? UserId { get; set; } = null!;
        public string PassPhraseClientId { get; set; } = null!;
        public string PassPhraseUserId { get; set; } = null!;
        public string? SupervisorId { get; set; }
        public string? DoseSpotBaseURL { get; set; }
    }
}
