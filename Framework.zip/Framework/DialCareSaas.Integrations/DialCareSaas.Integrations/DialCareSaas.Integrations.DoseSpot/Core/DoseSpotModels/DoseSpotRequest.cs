﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class DoseSpotRequest
    {
        public int ProviderID { get; set; }
        public int PatientID { get; set; }
    }
}
