﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models 
{
    public class LoginKeys
    {
        public string EncryptedClinicId { get; set; }
        public string EncryptedUserId { get; set; }
    }
}
