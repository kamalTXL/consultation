﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class Patient 
    {
        public int? PatientId { get; set; }
        public string? Prefix { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? MiddleName { get; set; }
        public string? Suffix { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public int? Gender { get; set; }
        public string? Email { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public int ZipCode { get; set; }
        public string? PhoneAdditional1 { get; set; }
        public string? PhoneAdditional2 { get; set; }
        public int? PhoneAdditionalType1 { get; set; }
        public int? PhoneAdditionalType2 { get; set; }
        public string? PrimaryPhone { get; set; }
        public int? PrimaryPhoneType { get; set; }
        public decimal? Weight { get; set; }
        public int? WeightMetric { get; set; }
        public decimal? Height { get; set; }
        public int? HeightMetric { get; set; }
        public Boolean? Active { get; set; }
        public string? Encounter { get; set; }
        public string? NonDoseSpotMedicalRecordNumber { get; set; }
        public Boolean? IsHospice { get; set; }

    }
}
