﻿

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{

    public class PatientData
    {
        public Patient? Patient { get; set; }
         public List<Prescription>? Prescriptions { get; set; }
        public List<SelfReportedMedication>? SelfReportedMedication { get; set; }
        public List<Pharmacy>? Pharmacies { get; set;}
        public List<ClinicianData>? Clinicians { get; set; } 
        public List<Clinic>? Clinics { get; set; }
        public List<Allergy>? Allergies { get; set; }
        public Result? Result { get; set; }
    }

    
}


