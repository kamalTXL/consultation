﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class Pharmacies
    {
        public int PharmacyId { get; set; }
        public string? StoreName { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? ZipCode { get; set; }
        public string? PrimaryPhone { get; set; }
        public int? PrimaryPhoneType { get; set; }
        public string? PrimaryFax { get; set; }        

    }
    public class PharmaciesResponse
    {
        public List<Pharmacies>? Items { get; set; }
        public Result? Result { get; set; }
    }
}
