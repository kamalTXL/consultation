﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class Pharmacy
    {
        public bool? IsPreferred { get; set; }
        public bool? IsDefault { get; set; }
        public int? PharmacyId { get; set; }
        public string? StoreName { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? ZipCode { get; set; }
        public string? PrimaryPhone { get; set; }
        public int? PrimaryPhoneType { get; set; }
        public string? PrimaryFax { get; set; }
        public string? PhoneAdditional1 { get; set; }
        public int? PhoneAdditionalType1 { get; set; }
        public string? PhoneAdditional2 { get; set; }
        public int? PhoneAdditionalType2 { get; set; }
        public string? PhoneAdditional3 { get; set; }
        public int? PhoneAdditionalType3 { get; set; }
        public string[]? PharmacySpecialties { get; set; }
        public int? ServiceLevel { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
    }

}
