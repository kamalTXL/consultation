﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class PharmacyRequest 
    {      
        public int PatientId { get; set; } 
        public int PharmacyId { get; set; }
        public bool SetAsPrimary { get; set; }
    }

    public class PharmacyPostRequest 
    {
        public bool SetAsPrimary { get; set; }
    }
}
