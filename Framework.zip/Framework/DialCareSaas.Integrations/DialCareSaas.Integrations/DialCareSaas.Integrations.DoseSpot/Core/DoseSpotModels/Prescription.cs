﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class Prescription
    {
        public int? PrescriptionId { get; set; }
        public DateTime? WrittenDate { get; set; }
        public string? Directions { get; set; }
        public string? Quantity { get; set; }
        public int? DispenseUnitId { get; set; }
        public string? DispenseUnitDescription { get; set; }
        public string? Refills { get; set; }
        public int? DaysSupply { get; set; }
        public int? PharmacyId { get; set; }
        public string? PharmacyNotes { get; set; }
        public bool? NoSubstitutions { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? LastFillDate { get; set; }
        public int? PrescriberId { get; set; }
        public int? PrescriberAgentId { get; set; }
        public string? RxReferenceNumber { get; set; }
        public int? Status { get; set; }
        public bool? Formulary { get; set; }
        public int? EligibilityId { get; set; }
        public int? Type { get; set; }
        public string? NonDoseSpotPrescriptionId { get; set; }
        public bool? ErrorIgnored { get; set; }
        public int? SupplyId { get; set; }
        public int? CompoundId { get; set; }
        public int? FreeTextType { get; set; }
        public int? ClinicId { get; set; }
        public int? SupervisorId { get; set; }
        public bool? IsUrgent { get; set; }
        public bool? IsRxRenewal { get; set; }
        public string? RxRenewalNote { get; set; }
        public int? PatientMedicationId { get; set; }
        public int? MedicationStatus { get; set; }
        public string? Comment { get; set; }
        public DateTime? DateInactive { get; set; }
        public string? Encounter { get; set; }
        public string? DoseForm { get; set; }
        public string? Route { get; set; }
        public string? Strength { get; set; }
        public string? GenericProductName { get; set; }
        public int? LexiGenProductId { get; set; }
        public int? LexiDrugSynId { get; set; }
        public int? LexiSynonymTypeId { get; set; }
        public string? LexiGenDrugId { get; set; }
        public string? RxCUI { get; set; }
        public bool? OTC { get; set; }
        public string? NDC { get; set; }
        public string? Schedule { get; set; }
        public string? DisplayName { get; set; }
        public string? MonographPath { get; set; }
        public string? DrugClassification { get; set; }
        public List<StateSchedule>? StateSchedules { get; set; }
        public bool? Brand { get; set; }
    }
    public class StateSchedule
    {
        public string? StateName { get; set; }
        public int? Schedule { get; set; } 
    }
}
