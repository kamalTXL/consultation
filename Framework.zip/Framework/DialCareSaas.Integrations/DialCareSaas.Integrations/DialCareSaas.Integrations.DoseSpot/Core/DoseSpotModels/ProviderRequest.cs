﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class ProviderRequest : Clinician
    {
        public int ProviderID { get; set; }
        public string DoseSpot_ProviderID { get; set; } = string.Empty;
    }
}
