﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models   
{

    public class ResponseResult
    {
        public string ResultCode { get; set; }
        public string ResultDescription { get; set; }
    }

    public class Result
    {
        public string ResultCode { get; set; }
        public string ResultDescription { get; set; }
    }

    public class PatientResponse
    {
        public int Id { get; set; }
        public Result Result { get; set; }
    }

    public class PharmacyResponse
    {
        public ResponseResult Result { get; set; } 
    }
   
}
