﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class SelfReportedMedication
    {
        public int? SelfReportedMedicationId { get; set; }
        public DateTime? DateReported { get; set; }
        public DateTime? WrittenDate { get; set; }
        public string? Directions { get; set; }
        public string? Quantity { get; set; }
        public int? DispenseUnitId { get; set; }
        public string? DispenseUnitDescription { get; set; }
        public string? Refills { get; set; }
        public int? DaysSupply { get; set; }
        public int? PatientMedicationId { get; set; }
        public int? MedicationStatus { get; set; }
        public string? Comment { get; set; }
        public DateTime? DateInactive { get; set; }
        public string? Encounter { get; set; }
        public string? DoseForm { get; set; }
        public string? Route { get; set; }
        public string? Strength { get; set; }
        public string? GenericProductName { get; set; }
        public string? GenericDrugName { get; set; }
        public int? LexiGenProductId { get; set; }
        public int? LexiDrugSynId { get; set; }
        public int? LexiSynonymTypeId { get; set; }
        public string? LexiGenDrugId { get; set; }
        public string? RxCUI { get; set; }
        public bool? OTC { get; set; }
        public string? NDC { get; set; }
        public string? Schedule { get; set; }
        public string? DisplayName { get; set; }
        public string? MonographPath { get; set; }
        public string? DrugClassification { get; set; }
        public List<StateSchedule>? StateSchedules { get; set; }
        public bool? Brand { get; set; }
    }
}
