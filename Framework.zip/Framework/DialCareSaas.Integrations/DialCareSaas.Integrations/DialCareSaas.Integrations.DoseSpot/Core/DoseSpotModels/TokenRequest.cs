﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models
{
    public class TokenRequest
    {
        public string? grant_type { get; set; }
        public string? Username { get; set; }
        public string? Password { get; set; }
    }

}
