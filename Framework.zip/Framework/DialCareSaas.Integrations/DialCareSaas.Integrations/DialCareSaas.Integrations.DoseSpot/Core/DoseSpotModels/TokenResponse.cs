﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Core.Models 
{
    public class TokenResponse : Token
    {
        public int expires_in { get; set; }
        public int userName { get; set; } 
        public bool Success { get; set; }
    }
}
