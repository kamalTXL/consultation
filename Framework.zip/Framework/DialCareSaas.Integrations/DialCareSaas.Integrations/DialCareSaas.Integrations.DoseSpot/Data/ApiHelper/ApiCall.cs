﻿using System.Net.Http.Json;

namespace DialCareSaas.Integrations.DoseSpot.Data
{
    public class ApiCall<T> : IApiCall<T> where T : class
    {
        private readonly IToken objToken;
        public ApiCall(IToken token)
        {
            objToken = token;
        }

        public async Task<string> GetAsync(string url)
        {            
            string token = await objToken.GetToken();
            HttpClient client = GetClient(token);
            var requestMessage = new HttpRequestMessage(HttpMethod.Get, url);

            //Make the request
            var apiResponse = await client.SendAsync(requestMessage);
            string responseBody = await apiResponse.EnsureSuccessStatusCode().Content.ReadAsStringAsync();

            return responseBody;
        }
        public async Task<string> PostAsync(string url, T data)
        {
            string token = await objToken.GetToken();
            HttpClient client = GetClient(token);
            string responseBody = string.Empty;
            try
            {
                //Make the request
                var apiResponse = await client.PostAsJsonAsync(url, data);
                responseBody = await apiResponse.EnsureSuccessStatusCode().Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                responseBody = ex.Message;
            }
            return responseBody;
        }
        private HttpClient GetClient(string token)
        {
            HttpClient client = new HttpClient();
            Uri baseUri = new Uri("https://my.staging.dosespot.com");
            client.BaseAddress = baseUri;
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.ConnectionClose = true;

            if (token != "" || token != null)
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
            }
            return client;
        }

    }
}
