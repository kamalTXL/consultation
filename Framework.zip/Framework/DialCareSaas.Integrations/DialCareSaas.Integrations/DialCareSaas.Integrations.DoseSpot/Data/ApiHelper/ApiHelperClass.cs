﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Data
{
    public static class ApiHelperClass<T>
    {
        public static async Task<string> GetAsync(string url, string accessToken, string baseUrl)
        {
            HttpClient client = GetClient(accessToken, baseUrl);
            var requestMessage = new HttpRequestMessage(HttpMethod.Get, url);

            //Make the request
            var apiResponse = await client.SendAsync(requestMessage);
            string responseBody = await apiResponse.EnsureSuccessStatusCode().Content.ReadAsStringAsync();

            return responseBody;
        }
        public static async Task<string> PostAsync(string url, T data, string accessToken, string baseUrl)
        {           
            HttpClient client = GetClient(accessToken, baseUrl);
            string responseBody = string.Empty;
            try
            {
                //Make the request
                var apiResponse = await client.PostAsJsonAsync(url, data);
                responseBody = await apiResponse.EnsureSuccessStatusCode().Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                responseBody = ex.Message;
            }
            return responseBody;
        }
        private static HttpClient GetClient(string token, string baseUrl)
        {
            HttpClient client = new HttpClient();
            Uri baseUri = new Uri(baseUrl);
            client.BaseAddress = baseUri;
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.ConnectionClose = true;

            if (token != "" || token != null)
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
            }
            return client;
        }
    }
}
