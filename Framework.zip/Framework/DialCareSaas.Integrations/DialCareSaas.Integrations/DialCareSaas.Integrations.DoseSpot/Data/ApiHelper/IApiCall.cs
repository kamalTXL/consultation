﻿namespace DialCareSaas.Integrations.DoseSpot.Data
{
    public interface IApiCall<T> where T : class
    {
        Task<string> GetAsync(string url);
        Task<string> PostAsync(string url, T data);
    }
}
