﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Integrations.DoseSpot.Data
{
    public interface IToken
    {
        Task<string> GetToken();
    }
}
