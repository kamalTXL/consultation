﻿using DialCareSaas.Integrations.DoseSpot.Core.Models;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace DialCareSaas.Integrations.DoseSpot.Data
{
    public class TokenService : IToken
    {
        private readonly DialCareSAASDoseSpotDBContextReadOnly _dialCareSAASDoseSpotDBContextReadOnly;


        public TokenService(DialCareSAASDoseSpotDBContextReadOnly dialCareSAASDoseSpotDBContextReadOnly)
        {
            _dialCareSAASDoseSpotDBContextReadOnly = dialCareSAASDoseSpotDBContextReadOnly;
        }
        public async Task<string> GetToken()
        {           
           var cong = _dialCareSAASDoseSpotDBContextReadOnly.DoseSpotConfiguration.FirstOrDefault();
            TokenResponse tokenResponse = new TokenResponse();

            try
            {
                #region TokenGeneration
                string ClinicId = cong.ClinicId;
                string ClinicKey = cong.ClinicKey;
                string UserId = cong.SupervisorId;
                string PassPhraseClientId = cong.ForClientId;
                string PassPhraseUserId = cong.ForUserId;

                DoseSpotHelperModel objHelper = new DoseSpotHelperModel();
                objHelper.UserId = UserId;
                objHelper.ClinicKey = ClinicKey;
                objHelper.ClinicId = ClinicId;
                objHelper.PassPhraseClientId = PassPhraseClientId;
                objHelper.PassPhraseUserId = PassPhraseUserId;

                IEncryptionHelper obj = new EncryptionHelper();
                LoginKeys keys = obj.GetLoginKeys(objHelper);

                TokenRequest request = new TokenRequest();
                request.grant_type = "password";
                request.Username = UserId;
                request.Password = keys.EncryptedUserId;

                var url = cong.DoseSpotUrl;

                //setup reusable http client
                HttpClient client = new HttpClient();
                Uri baseUri = new Uri(url);
                client.BaseAddress = baseUri;
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.ConnectionClose = true;



                //Post body content
                var values = new List<KeyValuePair<string, string>>();
                values.Add(new KeyValuePair<string, string>("grant_type", request.grant_type));
                values.Add(new KeyValuePair<string, string>("Username", request.Username));
                values.Add(new KeyValuePair<string, string>("Password", request.Password));
                var content = new FormUrlEncodedContent(values);

                string Username = cong.ClinicId;
                string Password = keys.EncryptedClinicId;

                var authenticationString = $"{Username}:{Password}";
                var base64EncodedAuthenticationString = Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(authenticationString));
                //generating token
                var requestMessage = new HttpRequestMessage(HttpMethod.Post, "/webapi/token");
                requestMessage.Headers.Authorization = new AuthenticationHeaderValue("Basic", base64EncodedAuthenticationString);
                requestMessage.Content = content;

                //make the request
                var response = await client.SendAsync(requestMessage);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(responseBody);
                #endregion

            }
            catch (Exception ex)
            {
                string e = ex.Message;
            }


            return tokenResponse.access_token;
        }

    }
}
