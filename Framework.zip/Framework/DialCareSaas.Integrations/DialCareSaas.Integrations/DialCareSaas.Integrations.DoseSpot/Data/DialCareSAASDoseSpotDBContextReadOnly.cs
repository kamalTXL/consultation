﻿using DialCareSaas.Integrations.DoseSpot.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace DialCareSaas.Integrations.DoseSpot.Data
{
    public class DialCareSAASDoseSpotDBContextReadOnly : DbContext
    {
        public DialCareSAASDoseSpotDBContextReadOnly(DbContextOptions<DialCareSAASDoseSpotDBContextReadOnly> options) : base(options)
        {
            
        }

        public DbSet<DoseSpotClinic> DoseSpotClinics { get; set; }
        public DbSet<DoseSpotConfiguration> DoseSpotConfiguration { get; set; }
    }
}