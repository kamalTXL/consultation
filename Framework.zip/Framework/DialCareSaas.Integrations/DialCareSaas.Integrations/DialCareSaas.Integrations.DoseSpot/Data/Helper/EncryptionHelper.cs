﻿using DialCareSaas.Integrations.DoseSpot.Core.Models;
using System.Security.Cryptography;

namespace DialCareSaas.Integrations.DoseSpot.Data
{
    public class EncryptionHelper : IEncryptionHelper
    {
        public LoginKeys GetLoginKeys(DoseSpotHelperModel doseSpotHelperModel)
        {
            LoginKeys loginKeys = new LoginKeys();
            var clinic_Id = doseSpotHelperModel.PassPhraseClientId + doseSpotHelperModel.ClinicKey;
            var user_Id = doseSpotHelperModel.UserId + doseSpotHelperModel.PassPhraseUserId + doseSpotHelperModel.ClinicKey;
            loginKeys.EncryptedClinicId = doseSpotHelperModel.PassPhraseClientId + EncryptKey(clinic_Id).Replace("==", "");
            loginKeys.EncryptedUserId = EncryptKey(user_Id).Replace("==", "");

            return loginKeys;
        }
        private string EncryptKey(string key)
        {
            string strBase64 = string.Empty;
            var result = System.Text.Encoding.UTF8.GetBytes(key);
            using (SHA512 obj = new SHA512Managed())
            {
                var hashkey = obj.ComputeHash(result);
                strBase64 = Convert.ToBase64String(hashkey);
            }
            return strBase64;
        }
    }
}
