﻿using DialCareSaas.Integrations.DoseSpot.Core.Models;

namespace DialCareSaas.Integrations.DoseSpot.Data
{
    public interface IEncryptionHelper
    {
        LoginKeys GetLoginKeys(DoseSpotHelperModel doseSpotHelperModel);
    }
}
