﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DialCareSaas.Serilog.Model
{
    public class LogRequestModel
    {
        public string LogType { get; set; }        
        public string? PortalType { get; set; }
        public string Message { get; set; }
        [JsonIgnore]
        public string? CallFrom { get; set; }

    }
}
