﻿using DialCareSaas.Serilog.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Serilog.Services
{
    public interface ISerilogService
    {
        public Response<bool> CreateLog(LogRequestModel model);
        public void CloseAndFlush();
    }
}
