﻿using Azure.Core;
using DialCareSaas.Serilog.Model;
using DialCareSaas.Serilog.Utility.Enums;
using Microsoft.Extensions.Configuration;
using Serilog;
using Serilog.Events;
using Serilog.Sinks.AzureBlobStorage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DialCareSaas.Serilog.Services
{
    public class SerilogService : ISerilogService
    {
        private readonly IConfiguration _configuration;
        private readonly string connectionString;
        private readonly string containerName;
        private readonly string folderName;
        public SerilogService(IConfiguration configuration)
        {
            _configuration = configuration;
            connectionString = _configuration.GetConnectionString("ConnectionStringsForBlobStorage"); 
            if (!string.IsNullOrEmpty(connectionString))
            {
                _configuration["Serilog:WriteTo:1:Args:connectionString"] = connectionString;
                Log.Logger = new LoggerConfiguration()
                    .ReadFrom.Configuration(_configuration)
                    .WriteTo.AzureBlobStorage(connectionString, LogEventLevel.Information)
                    .CreateLogger();
            }
        }
        public Response<bool> CreateLog(LogRequestModel model)
        {
            if (model == null)
            {
                return new Response<bool>() { Result = false };
            }
            if (!string.IsNullOrEmpty(model.CallFrom) && model.CallFrom!.ToLower() == Convert.ToString(CallFromEnums.Frontend).ToLower())
            {
                var folderName = $"{model.PortalType}_UI";
                var bn = new BlobNameFactory(!string.IsNullOrEmpty(folderName) ? $"{folderName}{"/"}{"{yyyy}-{MM}-{dd}_log.txt"}" : $"{"{yyyy}-{MM}-{dd}_log.txt"}");
                Log.Logger = new LoggerConfiguration()
              .WriteTo.AzureBlobStorage(connectionString, LogEventLevel.Information, "logs", bn.GetBlobName(new DateTimeOffset((DateTime.Now))))
              .CreateLogger();
            }
            if (model.LogType == Convert.ToString(LogTypeEnums.Error))
                Log.Logger.Error(model.Message);
            else if (model.LogType == Convert.ToString(LogTypeEnums.Warning))
                Log.Logger.Warning(model.Message);
            else if (model.LogType == Convert.ToString(LogTypeEnums.Debug))
                Log.Logger.Debug(model.Message);
            else if (model.LogType == Convert.ToString(LogTypeEnums.Information))
                Log.Logger.Information(model.Message);
            else if (model.LogType == Convert.ToString(LogTypeEnums.Fatal))
                Log.Logger.Fatal(model.Message);
            return new Response<bool>() { Result = true };
        }
        public void CloseAndFlush()
        {
            Log.CloseAndFlush();
        }
    }
}
