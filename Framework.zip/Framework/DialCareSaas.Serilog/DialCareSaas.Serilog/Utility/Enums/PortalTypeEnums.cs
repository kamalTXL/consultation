﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialCareSaas.Serilog.Utility.Enums
{
    public enum PortalTypeEnums
    {
        Provider,
        Patient,
        Admin,
        Other
    }
}
