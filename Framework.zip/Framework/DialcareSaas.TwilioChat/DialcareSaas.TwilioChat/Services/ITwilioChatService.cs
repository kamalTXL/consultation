﻿namespace DialcareSaas.TwilioChat.Services
{
    public interface ITwilioChatService
    {
        public string GetTwilioChatJwt(string serviceSID, string identity);
        public Task<string> GetTwilioChatHistory(string channelId);
    }
}
