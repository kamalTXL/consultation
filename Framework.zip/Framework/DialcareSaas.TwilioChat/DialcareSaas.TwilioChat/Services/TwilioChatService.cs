﻿using Consultations.Core.Domain;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Twilio;
using Twilio.Jwt.AccessToken;
using Twilio.Rest.Conversations.V1;
using Twilio.Rest.Conversations.V1.Conversation;

namespace DialcareSaas.TwilioChat.Services
{
    public class TwilioChatService : ITwilioChatService
    {
        readonly TwilioSettings _twilioSettings;
        public TwilioChatService(IOptions<TwilioSettings> twilioOptions)
        {
           
            _twilioSettings = twilioOptions?.Value ?? throw new ArgumentNullException(nameof(twilioOptions));
        }
        public string GetTwilioChatJwt(string serviceSID, string identity)
        {
            var grant = new ChatGrant
            {
                ServiceSid = serviceSID
            };
            var grants = new HashSet<IGrant> {
                {
                    grant
                } };
           var token = new Token(
                         _twilioSettings.AccountSid,
                         _twilioSettings.ApiKey,
                         _twilioSettings.ApiSecret,
                         identity,
                         grants: grants).ToJwt();

            return token;
        }

        public async Task<string> GetTwilioChatHistory(string channelId)
        {
            TwilioClient.Init(_twilioSettings.AccountSid, _twilioSettings.AuthToken);
            var conversation = ConversationResource.Fetch(pathSid: channelId);
            var messages = MessageResource.Read(
                pathConversationSid: channelId
            );
            string chatHistory = JsonConvert.SerializeObject(messages);
            return chatHistory;
        }
    }
}
